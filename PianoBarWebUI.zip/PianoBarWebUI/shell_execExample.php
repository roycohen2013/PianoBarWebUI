<?php

	$output = shell_exec('ls -lart');
	echo "<pre>$output</pre>";

?>